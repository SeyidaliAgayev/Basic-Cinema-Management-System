package service;

public interface CinemaService {
    boolean addFilm();
    boolean updateFilm();
    boolean deleteFilm();
    void showFilm();
    void searchFilm();
}
