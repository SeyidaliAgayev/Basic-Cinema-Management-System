package service;

public interface CinemaManagementService {
    void cinemaManagement();
}
