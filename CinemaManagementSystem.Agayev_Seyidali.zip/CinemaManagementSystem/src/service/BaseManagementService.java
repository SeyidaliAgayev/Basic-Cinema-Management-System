package service;

public interface BaseManagementService {
    void baseManagement();
}
