package globalData;

import model.Cinema;
import model.Customer;

public class GlobalData {
    public static Customer[] customers;
    public static Cinema[] cinemas;
}
